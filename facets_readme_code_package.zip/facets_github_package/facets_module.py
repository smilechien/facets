"""Minimal FACETS-style helper module.

This standalone module was distilled from FACETS-related logic in the uploaded
`raschonlinePCM` project so it can be reused in a GitHub repository as an
independent example.

Main features
-------------
- robust CSV reading
- FACETS long-format detection
- optional wide-panel detection and reshaping
- numeric facet label prefixing
- additive-model fit summaries per facet level
- CSV/JSON export for quick reporting
"""

from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd


def read_csv_robust(csv_path: str | Path) -> pd.DataFrame:
    """Read CSV using a small set of common encodings."""
    encodings = ["utf-8-sig", "utf-8", "cp950", "big5", "latin1"]
    last_error = None
    for enc in encodings:
        try:
            return pd.read_csv(csv_path, encoding=enc)
        except Exception as exc:  # pragma: no cover - fallback behavior
            last_error = exc
    raise ValueError(f"Unable to read CSV. Last error: {last_error}")


def detect_segment_judge_wide_df(df: pd.DataFrame, id_col: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Detect wide judge panels like A01, A02, ..., B01, B02, ..."""
    try:
        if df is None or df.empty or len(df.columns) < 4:
            return None

        work = df.dropna(how="all").copy()
        if work.empty:
            return None

        dancer_col = id_col if id_col in work.columns else work.columns[0]
        profile_names = {"profile", "profile2", "true_label", "truelabel", "label"}
        profile_col = None
        for c in work.columns:
            if str(c).strip().lower() in profile_names:
                profile_col = c
                break

        pat = re.compile(r"^([A-Za-z]+)(\d+)$")
        score_meta = []
        non_pattern = []
        for c in work.columns:
            if c == dancer_col or c == profile_col:
                continue
            m = pat.match(str(c).strip())
            if m:
                seg, judge = m.groups()
                score_meta.append((c, seg, judge))
            else:
                non_pattern.append(c)

        if len(score_meta) < 4:
            return None

        judge_to_segments: Dict[str, List[str]] = {}
        seg_order: List[str] = []
        seg_to_judges: Dict[str, List[str]] = {}
        for c, seg, judge in score_meta:
            if seg not in seg_order:
                seg_order.append(seg)
            judge_to_segments.setdefault(judge, []).append(seg)
            seg_to_judges.setdefault(seg, []).append(judge)

        repeated_judges = [j for j, segs in judge_to_segments.items() if len(set(segs)) >= 2]
        if len(repeated_judges) < 2 or len(seg_order) < 2:
            return None

        first_seg = seg_order[0]
        judge_order = [judge for c, seg, judge in score_meta if seg == first_seg]
        if len(judge_order) < 2:
            return None

        for seg in seg_order[1:]:
            overlap = len(set(seg_to_judges.get(seg, [])) & set(judge_order))
            if overlap < max(2, len(judge_order) // 2):
                return None

        return {
            "dancer_col": dancer_col,
            "profile_col": profile_col,
            "score_meta": score_meta,
            "segment_order": seg_order,
            "judge_order": judge_order,
            "non_pattern_cols": non_pattern,
        }
    except Exception:
        return None


def is_facets_long_df(df: pd.DataFrame) -> bool:
    """Return True for FACETS-style long data.

    Rules:
    - at least 2 columns
    - final column is numeric for most rows
    - preceding columns are facet identifiers
    - common wide judge panels are excluded
    """
    try:
        if df is None:
            return False
        df = df.dropna(how="all").copy().reset_index(drop=True)
        if len(df.columns) < 2 or df.empty:
            return False
        if detect_segment_judge_wide_df(df) is not None:
            return False
        score_col = df.columns[-1]
        score = pd.to_numeric(df[score_col], errors="coerce")
        if score.notna().mean() < 0.8:
            return False
        facet_cols = list(df.columns[:-1])
        if not facet_cols:
            return False
        for col in facet_cols:
            s = df[col]
            ok = s.notna() & (s.astype(str).str.strip() != "")
            if ok.sum() == 0:
                return False
        return True
    except Exception:
        return False


def wide_to_facets_long_df(df: pd.DataFrame, id_col: Optional[str] = None) -> pd.DataFrame:
    """Transform supported wide panels into long FACETS format."""
    info = detect_segment_judge_wide_df(df, id_col=id_col)
    if not info:
        raise ValueError("Data is not a supported wide FACETS judge panel.")

    dancer_col = info["dancer_col"]
    score_meta = info["score_meta"]
    rows = []
    for _, row in df.iterrows():
        dancer = row.get(dancer_col)
        if pd.isna(dancer) or str(dancer).strip() == "":
            continue
        for col, seg, judge in score_meta:
            score = pd.to_numeric(pd.Series([row.get(col)]), errors="coerce").iloc[0]
            if pd.isna(score):
                continue
            rows.append({
                "Dancer": str(dancer),
                "Judge": str(judge),
                "Segment": str(seg),
                "Score": float(score),
            })
    if not rows:
        raise ValueError("Wide FACETS panel detected, but no numeric scores were found.")
    return pd.DataFrame(rows, columns=["Dancer", "Judge", "Segment", "Score"])


def prefix_numeric_facet_terms(df: pd.DataFrame, facet_cols: List[str]) -> tuple[pd.DataFrame, List[str]]:
    """Prefix numeric-like facet levels with the facet name for clearer labels.

    Example:
    Judge: 1,2,3 -> Judge1, Judge2, Judge3
    """
    out = df.copy()
    changed: List[str] = []
    for col in facet_cols:
        if col not in out.columns:
            continue
        s = out[col]
        nonmiss = s.dropna()
        if len(nonmiss) == 0:
            continue
        txt = nonmiss.astype(str).str.strip()
        txt = txt[txt != ""]
        if len(txt) == 0:
            continue
        num = pd.to_numeric(txt, errors="coerce")
        if float(num.notna().mean()) < 0.80:
            continue

        def _fmt(v: Any) -> Any:
            if pd.isna(v):
                return v
            sv = str(v).strip()
            if sv == "":
                return sv
            x = pd.to_numeric(pd.Series([sv]), errors="coerce").iloc[0]
            if pd.isna(x):
                return sv
            xf = float(x)
            if abs(xf - round(xf)) < 1e-9:
                xs = str(int(round(xf)))
            else:
                xs = f"{xf}".rstrip("0").rstrip(".")
            return f"{col}{xs}"

        out[col] = s.map(_fmt)
        changed.append(str(col))
    return out, changed


def _mnsq_to_zstd(mnsq: float, df_like: float) -> float:
    m = max(float(mnsq), 1e-12)
    d = max(float(df_like), 1.0)
    return float((np.cbrt(m) - 1.0) * (3.0 * np.sqrt(d / 2.0)))


def facets_additive_fit(use: pd.DataFrame, facet_cols: List[str], score_col: str) -> Dict[str, pd.DataFrame]:
    """Approximate facet-level INFIT/OUTFIT statistics using an additive model.

    Notes
    -----
    This is intentionally lightweight and is not a full many-facet Rasch estimator.
    It is designed for practical diagnostics, prototypes, and web dashboards.
    """
    y = pd.to_numeric(use[score_col], errors="coerce").to_numpy(dtype=float)
    mask = np.isfinite(y)
    work = use.loc[mask, facet_cols].copy()
    y = y[mask]
    if len(y) == 0:
        return {}

    x_parts = [np.ones((len(work), 1), dtype=float)]
    for col in facet_cols:
        cats = work[col].astype(str).fillna("")
        dummies = pd.get_dummies(cats, prefix=str(col), dtype=float)
        if dummies.shape[1] > 1:
            dummies = dummies.iloc[:, 1:]
        else:
            dummies = dummies.iloc[:, 0:0]
        if dummies.shape[1] > 0:
            x_parts.append(dummies.to_numpy(dtype=float))

    x = np.hstack(x_parts)
    n, p = x.shape
    try:
        coef, *_ = np.linalg.lstsq(x, y, rcond=None)
        yhat = x @ coef
        xtx_inv = np.linalg.pinv(x.T @ x)
        h_mat = x @ xtx_inv
        h = np.sum(h_mat * x, axis=1)
    except Exception:
        yhat = np.full(len(y), float(np.nanmean(y) if len(y) else 0.0), dtype=float)
        h = np.zeros(len(y), dtype=float)

    yhat = np.clip(yhat, float(np.nanmin(y)), float(np.nanmax(y)))
    resid = y - yhat

    df_resid = max(n - p, 1)
    sigma2 = float(np.nansum(resid ** 2) / df_resid) if len(resid) else 1.0
    sigma2 = max(sigma2, 1e-8)

    h = np.clip(np.asarray(h, dtype=float), 0.0, 0.95)
    adj_var = sigma2 * np.maximum(1.0 - h, 1e-6)
    std_sq = (resid ** 2) / adj_var

    y_bar = float(np.nanmean(y))
    y_sd = max(float(np.nanstd(y)), 1e-6)
    info_w = 1.0 / (1.0 + ((yhat - y_bar) / y_sd) ** 2)
    info_w = np.clip(info_w, 1e-6, None)

    fit_tables: Dict[str, pd.DataFrame] = {}
    for col in facet_cols:
        levels = work[col].astype(str)
        rows = []
        for lev in pd.unique(levels):
            m = (levels == lev).to_numpy()
            n_lev = int(np.sum(m))
            if n_lev <= 0:
                continue
            outfit = float(np.nanmean(std_sq[m]))
            w = info_w[m]
            infit = float(np.nansum(w * std_sq[m]) / max(np.nansum(w), 1e-8))
            eff_n = float((np.nansum(w) ** 2) / max(np.nansum(w ** 2), 1e-8))
            infit_z = _mnsq_to_zstd(infit, max(eff_n - 1.0, 1.0))
            outfit_z = _mnsq_to_zstd(outfit, max(n_lev - 1.0, 1.0))
            rows.append((str(lev), infit, outfit, infit_z, outfit_z))

        tbl = pd.DataFrame(rows, columns=[col, "INFIT_MNSQ", "OUTFIT_MNSQ", "INFIT_ZSTD", "OUTFIT_ZSTD"])
        for fit_col in ["INFIT_MNSQ", "OUTFIT_MNSQ"]:
            mu = float(pd.to_numeric(tbl[fit_col], errors="coerce").mean()) if len(tbl) else 1.0
            mu = mu if np.isfinite(mu) and mu > 1e-8 else 1.0
            tbl[fit_col] = pd.to_numeric(tbl[fit_col], errors="coerce") / mu
        tbl["INFIT_ZSTD"] = tbl["INFIT_MNSQ"].map(
            lambda m: _mnsq_to_zstd(m, max(len(y) / max(len(tbl), 1) - 1.0, 1.0))
        )
        tbl["OUTFIT_ZSTD"] = tbl["OUTFIT_MNSQ"].map(
            lambda m: _mnsq_to_zstd(m, max(len(y) / max(len(tbl), 1) - 1.0, 1.0))
        )
        fit_tables[col] = tbl
    return fit_tables


def run_facets_demo(csv_path: str | Path, outdir: str | Path = "outputs") -> Dict[str, Any]:
    """Run a minimal FACETS-style workflow and export outputs."""
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    raw = read_csv_robust(csv_path).dropna(how="all").reset_index(drop=True)
    if is_facets_long_df(raw):
        long_df = raw.copy()
    else:
        long_df = wide_to_facets_long_df(raw)

    facet_cols = list(long_df.columns[:-1])
    score_col = long_df.columns[-1]
    long_df, changed = prefix_numeric_facet_terms(long_df, facet_cols)

    fit_tables = facets_additive_fit(long_df, facet_cols, score_col)

    long_df.to_csv(outdir / "facets_long_clean.csv", index=False, encoding="utf-8-sig")
    for facet_name, table in fit_tables.items():
        safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", str(facet_name)).strip("_") or "facet"
        table.to_csv(outdir / f"facet_{safe_name}_estimates.csv", index=False, encoding="utf-8-sig")

    summary = {
        "n_rows": int(len(long_df)),
        "facet_columns": facet_cols,
        "score_column": score_col,
        "numeric_facet_labels_prefixed": changed,
        "overall_score_mean": float(pd.to_numeric(long_df[score_col], errors="coerce").mean()),
        "fit_tables": list(fit_tables.keys()),
    }
    (outdir / "facets_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a minimal FACETS-style demo workflow.")
    parser.add_argument("csv_path", help="Path to FACETS long-format CSV or supported wide judge panel CSV")
    parser.add_argument("--outdir", default="outputs", help="Directory to store exported results")
    args = parser.parse_args()

    summary = run_facets_demo(args.csv_path, args.outdir)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
